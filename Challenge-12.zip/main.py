n=int(input("Enter the year:"))
if(n==0):
    print("Please Enter the correct year")
elif(n%4==0):
    print("YEAR IS LEAP YEAR")
else:
    print("year is not leap year")